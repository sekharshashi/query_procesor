/**
 * Provides classes for representing data. 
 */
package query_processor.data;

