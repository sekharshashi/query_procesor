/**
 * Provides classes for testing query processing.
 */
package query_processor.test;