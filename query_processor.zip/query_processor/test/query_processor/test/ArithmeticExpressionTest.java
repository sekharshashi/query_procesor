package query_processor.test;

import query_processor.expression.ArithmeticExpression;
import query_processor.expression.ParsingException;
import query_processor.expression.UnboundVariableException;
import query_processor.expression.Variable;

public class ArithmeticExpressionTest {

	public static void main(String[] args) throws ParsingException, UnboundVariableException {
		String s = "Celsius * 9 / 5 + 32";
		System.out.println("arithmetic expression: " + s);
		ArithmeticExpression e = new ArithmeticExpression(s);
		Variable v = e.variable("Celsius");
		v.setType(Double.class);
		System.out.println("evaluation type: " + e.resultType());
		v.setValue(5);
		System.out.println("evaluation result: " + e.evaluate());
		e.print(System.out);
	}

}
