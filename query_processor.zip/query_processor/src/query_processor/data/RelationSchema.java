package query_processor.data;

import java.util.LinkedHashMap;

/**
 * A {@code RelationSchema} represents the schema of a relation.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
public class RelationSchema {

	/**
	 * An {@code InvalidRelationSchemaDefinition} is thrown if a {@code RelationSchema} is defined inappropriately.
	 * 
	 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
	 */
	public static class InvalidRelationSchemaDefinitionException extends Exception {

		/**
		 * Automatically generated serial version UID.
		 */
		private static final long serialVersionUID = -5993611676487221609L;

	}

	/**
	 * The names of the attributes of this {@code RelationSchema}.
	 */
	String[] attributeNames;

	/**
	 * The types of the attributes of this {@code RelationSchema}.
	 */
	Class<?>[] attributeTypes;

	/**
	 * Constructs a {@code RelationSchema}.
	 * 
	 * @param attributeNames
	 *            the names of the attributes of the {@code RelationSchema}
	 * @param attributeTypes
	 *            the types of the attributes of the {@code RelationSchema}
	 * @throws InvalidRelationSchemaDefinitionException
	 *             if the number of attribute names and the number of attribute types do not match
	 */
	public RelationSchema(String[] attributeNames, Class<?>[] attributeTypes)
			throws InvalidRelationSchemaDefinitionException {
		if (attributeNames.length != attributeTypes.length)
			throw new InvalidRelationSchemaDefinitionException();
		this.attributeNames = attributeNames;
		this.attributeTypes = attributeTypes;
	}

	/**
	 * Returns a string representation of this {@code RelationSchema}.
	 */
	@Override
	public String toString() {
		LinkedHashMap<String, String> m = new LinkedHashMap<String, String>();
		for (int i = 0; i < attributeNames.length; i++)
			m.put(attributeName(i), attributeType(i).getName());
		return m.toString();
	}

	/**
	 * Returns the number of attributes in this {@code RelationSchema}.
	 * 
	 * @return the number of attributes in this {@code RelationSchema}
	 */
	public int size() {
		return attributeNames.length;
	}

	/**
	 * Returns the name of the specified attribute.
	 * 
	 * @param i
	 *            the index of the attribute
	 * @return the name of the specified attribute
	 */
	public String attributeName(int i) {
		return attributeNames[i];
	}

	/**
	 * Returns the type of the specified attribute.
	 * 
	 * @param i
	 *            the index of the attribute
	 * @return the type of the specified attribute
	 */
	public Class<?> attributeType(int i) {
		return attributeTypes[i];
	}

	/**
	 * Returns the index of the specified attribute in this {@code RelationSchema} ({@code null} if no such attribute).
	 * 
	 * @param attributeName
	 *            the name of the attribute
	 * @return the index of the specified attribute in this {@code RelationSchema}; {@code null} if no such attribute
	 */
	public Integer index(String attributeName) {
		for (int i = 0; i < attributeNames.length; i++)
			if (attributeNames[i].equals(attributeName))
				return i;
		return null;
	}

}
