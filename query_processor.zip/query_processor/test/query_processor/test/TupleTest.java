package query_processor.test;

import java.io.IOException;

import query_processor.ExpressionEvaluator;
import query_processor.data.RelationSchema;
import query_processor.data.RelationSchema.InvalidRelationSchemaDefinitionException;
import query_processor.data.Tuple;
import query_processor.data.Tuple.TypeException;
import query_processor.expression.ArithmeticExpression;
import query_processor.expression.ParsingException;
import query_processor.expression.UnboundVariableException;

/**
 * This program tests the {@code Tuple} class.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 * 
 */
public class TupleTest {

	/**
	 * The main program.
	 * 
	 * @param args
	 *            the String arguments
	 * @throws ParsingException
	 *             if a parsing error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 * @throws TypeException
	 *             if a specified attribute value does not match the type of the corresponding attribute
	 * @throws InvalidRelationSchemaDefinitionException
	 *             if the number of attribute names and the number of attribute types do not match
	 * @throws ClassNotFoundException
	 *             if the class of a serialized object cannot be found
	 * @throws UnboundVariableException
	 *             if an {@code Expression} contains a variable whose value is not set
	 */
	public static void main(String[] args) throws ParsingException, IOException, TypeException,
			InvalidRelationSchemaDefinitionException, ClassNotFoundException, UnboundVariableException {
		RelationSchema schema = new RelationSchema(new String[] { "ID", "Celsius" },
				new Class<?>[] { Integer.class, Double.class });
		System.out.println("schema: " + schema);
		String s = "Celsius * 9 / 5 + 32";
		ArithmeticExpression expression = new ArithmeticExpression(s);
		System.out.println("arithmetic expression: " + s);
		ExpressionEvaluator e = new ExpressionEvaluator(expression, schema);
		Tuple t = new Tuple(schema, 1, 5.0);
		System.out.println("tuple: " + t);
		System.out.println("result: " + e.evaluate(t));
		byte[] b = t.bytes();
		System.out.println("size of tuple (serialized): " + b.length);
		t = new Tuple(schema, b);
		System.out.println("tuple: " + t);
	}

}
