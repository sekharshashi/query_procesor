package query_processor.test;

import java.io.PrintStream;
import java.util.Arrays;

import query_processor.AggregageOperator;
import query_processor.Operator;
import query_processor.aggregate.Minimum;
import query_processor.aggregate.Maximum;
import query_processor.aggregate.Average;
import query_processor.expression.ParsingException;

public class AggregateOperatorTest {

	public static void main(String[] args) throws ParsingException, InstantiationException {
		test(System.out);
	}

	public static void test(PrintStream out) throws ParsingException, InstantiationException {
		Operator o = ProjectionOperatorTest.inputOperator();

		out.println("input schema: " + o.outputSchema());
		out.println("input tuples:");
		while (o.hasNext())
			out.println(o.next());
		out.println();

		o.rewind(); // rewind the input operator
		AggregageOperator a = new AggregageOperator(o, new String[] { "Location" },
				new Class<?>[] { Minimum.class, Maximum.class, Average.class },
				new String[] { "Celsius", "Celsius", "Celsius" });
		out.println("grouping attributes: " + Arrays.toString(a.groupingAttributeNames()));
		out.println("aggregate functions: " + Arrays.toString(a.aggregateFunctions()));
		out.println("output schema: " + a.outputSchema());
		while (a.hasNext())
			out.println(a.next());
		out.println();
	}

}
