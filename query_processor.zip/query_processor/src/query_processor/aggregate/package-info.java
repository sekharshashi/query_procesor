/**
 * Provides implementations of aggregate functions.
 */
package query_processor.aggregate;

