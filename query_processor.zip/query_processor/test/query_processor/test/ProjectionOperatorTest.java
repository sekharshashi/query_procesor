package query_processor.test;

import java.io.PrintStream;
import java.util.Iterator;
import java.util.LinkedList;

import query_processor.Operator;
import query_processor.ProjectionOperator;
import query_processor.data.RelationSchema;
import query_processor.data.RelationSchema.InvalidRelationSchemaDefinitionException;
import query_processor.data.Tuple;
import query_processor.data.Tuple.TypeException;
import query_processor.expression.ParsingException;
import query_processor.expression.UnboundVariableException;

public class ProjectionOperatorTest {

	public static void main(String[] args) throws ParsingException, InvalidRelationSchemaDefinitionException, UnboundVariableException {
		test(System.out);
	}

	public static void test(PrintStream out) throws ParsingException, InvalidRelationSchemaDefinitionException, UnboundVariableException {
		Operator o = inputOperator();
		ProjectionOperator p = new ProjectionOperator(o, new String[] { "ID", "Fahrenheit" },
				new String[] { "ID", "Celsius * 9 / 5 + 32" });

		out.println("input schema: " + o.outputSchema());
		out.println("input tuples:");
		while (o.hasNext())
			out.println(o.next());
		out.println();

		o.rewind(); // rewind the input operator
		out.println("output schema: " + p.outputSchema());
		out.println("output tuples:");
		while (p.hasNext())
			out.println(p.next());
	}

	public static Operator inputOperator() {

		try {
			return new Operator() {

				RelationSchema schema = new RelationSchema(new String[] { "ID", "Location", "Celsius" },
						new Class<?>[] { Integer.class, Integer.class, Double.class });

				LinkedList<Tuple> tuples = new LinkedList<Tuple>();

				Iterator<Tuple> i;

				{
					for (int i = 0; i < 12; i++) // prepare 12 tuples
						try {
							tuples.add(new Tuple(schema, new Object[] { new Integer(i), new Integer(i/4), new Double(i) }));
						} catch (TypeException e) {
							e.printStackTrace();
						}
					i = tuples.iterator();
				}

				@Override
				public RelationSchema outputSchema() {
					return schema;
				}

				@Override
				public boolean hasNext() {
					return i.hasNext();
				}

				@Override
				public Tuple next() {
					return i.next();
				}

				@Override
				public void rewind() {
					i = tuples.iterator();
				}

			};
		} catch (InvalidRelationSchemaDefinitionException e) {
			e.printStackTrace();
			return null;
		}
	}

}
