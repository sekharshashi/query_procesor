package query_processor.test;

import java.io.PrintStream;

import query_processor.Operator;
import query_processor.SelectionOperator;
import query_processor.expression.ParsingException;
import query_processor.expression.UnboundVariableException;

public class SelectionOperatorTest {

	public static void main(String[] args) throws ParsingException, UnboundVariableException {
		test(System.out);
	}

	public static void test(PrintStream out) throws ParsingException, UnboundVariableException {
		Operator o = ProjectionOperatorTest.inputOperator();

		out.println("input schema: " + o.outputSchema());
		out.println("input tuples:");
		while (o.hasNext())
			out.println(o.next());
		out.println();

		String predicate = "Celsius < 5";
		o.rewind(); // rewind the input operator
		SelectionOperator s = new SelectionOperator(o, predicate);
		out.println("predicate: " + predicate);
		out.println("output tuples:");
		while (s.hasNext())
			out.println(s.next());
		out.println();

		predicate = "Celsius > 5";
		o.rewind(); // rewind the input operator
		s = new SelectionOperator(o, predicate);
		out.println("predicate: " + predicate);
		out.println("output tuples:");
		while (s.hasNext())
			s.next();
		s.rewind();
		while (s.hasNext())
			out.println(s.next());
	}

}
