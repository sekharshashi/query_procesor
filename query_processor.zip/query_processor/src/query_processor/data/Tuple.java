package query_processor.data;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

/**
 * A {@code Tuple} represents an object containing a number of attributes.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
public class Tuple {

	/**
	 * The attribute values of this {@code Tuple}.
	 */
	Object[] attributeValues;

	/**
	 * Constructs a {@code Tuple}.
	 * 
	 * @param schema
	 *            a {@code RelationSchema}
	 * @param attributeValues
	 *            the attribute values of the {@code Tuple}
	 * @throws TypeException
	 *             if a specified attribute value does not match the type of the corresponding attribute
	 */
	public Tuple(RelationSchema schema, Object... attributeValues) throws TypeException {
		this.attributeValues = new Object[schema.attributeTypes.length];
		for (int i = 0; i < schema.attributeTypes.length; i++)
			set(schema, i, attributeValues[i]);
	}

	/**
	 * Constructs a {@code Tuple} from the specified byte array.
	 * 
	 * @param schema
	 *            a {@code RelationSchema}
	 * @param bytes
	 *            a byte array
	 * @throws TypeException
	 *             if an attribute value does not match the type of the corresponding attribute
	 * @throws IOException
	 *             if an I/O error occurs
	 * @throws ClassNotFoundException
	 *             if the class of a serialized object cannot be found
	 */
	public Tuple(RelationSchema schema, byte[] bytes) throws TypeException, IOException, ClassNotFoundException {
		this.attributeValues = new Object[schema.attributeTypes.length];
		ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bytes));
		for (int i = 0; i < schema.attributeTypes.length; i++)
			set(schema, i, read(schema.attributeType(i), in));
	}

	/**
	 * Returns the value of the specified attribute.
	 * 
	 * @param i
	 *            the index of an attribute
	 * @return the value of the specified attribute
	 */
	public Object attributeValue(int i) {
		return attributeValues[i];
	}

	/**
	 * Returns a string representation of this {@code Tuple}.
	 */
	@Override
	public String toString() {
		return Arrays.toString(attributeValues);
	}

	/**
	 * Sets the value of the specified attribute.
	 * 
	 * @param schema
	 *            a {@code RelationSchema}
	 * @param i
	 *            the index of an attribute
	 * @param o
	 *            the value of the attribute
	 * @throws TypeException
	 *             if the specified object is not an instance of the type of the specified attribute
	 */
	public void set(RelationSchema schema, int i, Object o) throws TypeException {
		if (schema.attributeType(i).isInstance(o))
			attributeValues[i] = o;
		else
			throw new TypeException();
	}

	/**
	 * Returns a byte array that represents this {@code Tuple}.
	 * 
	 * @return a byte array that represents this {@code Tuple}
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	public byte[] bytes() throws IOException {
		ByteArrayOutputStream b = new ByteArrayOutputStream();
		ObjectOutputStream out = new ObjectOutputStream(b);
		for (int i = 0; i < attributeValues.length; i++)
			write(attributeValues[i], out);
		out.close();
		return b.toByteArray();
	}

	/**
	 * Writes the specified object to the specified {@code ObjectOutputStream}.
	 * 
	 * @param o
	 *            an object
	 * @param out
	 *            an {@code ObjectOutputStream}
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	protected void write(Object o, ObjectOutputStream out) throws IOException {
		if (o instanceof Integer)
			out.writeInt((Integer) o);
		else if (o instanceof Double)
			out.writeDouble((Double) o);
		else
			out.writeObject(o);
	}

	/**
	 * Reads an object of the specified type from the specified {@code ObjectInputStream}.
	 * 
	 * @param type
	 *            a type
	 * @param in
	 *            an {@code ObjectInputStream}
	 * @throws IOException
	 *             if an I/O error occurs
	 * @throws ClassNotFoundException
	 *             if the class of a serialized object cannot be found
	 */
	protected Object read(Class<?> type, ObjectInputStream in) throws IOException, ClassNotFoundException {
		if (type == Integer.class)
			return (Object) in.readInt();
		else if (type == Double.class)
			return (Object) in.readDouble();
		else
			return in.readObject();
	}

	/**
	 * A {@code TypeException} is thrown when an object is not an instance of an appropriate type.
	 * 
	 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
	 */
	public static class TypeException extends Exception {

		/**
		 * Automatically generated serial version UID.
		 */
		private static final long serialVersionUID = 2260118532930630008L;

	}

}
