/**
 * Provides classes for query processing.
 */
package query_processor;